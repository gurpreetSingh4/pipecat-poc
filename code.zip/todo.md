## We need to test following

### Recording

- recording transcript
- recording audio

### analysis

- call status: To check if all evaluation criteria met
- data collection on transcript: some variables that we need to collect from transcript
- some evaluation criteria: if goal of the call was completed
- transcript summary: Summary of the transcript
